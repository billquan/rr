module.exports = {
    secret: "my-secret-key"
};