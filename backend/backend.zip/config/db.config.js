// not currently using. Currently using env
module.exports = {
    HOST: "localhost",
    PORT: 5000,
    DB: "root"
};